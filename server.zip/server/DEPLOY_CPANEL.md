# Deploying the Stock Trading Signals backend on cPanel

What runs on your hosting: the **API** (logins, settings, signals, results), the **scanner**
(records every signal and closes it at target/stop), **emails** (alerts, verification, reports) and
**push notifications** (through Firebase Cloud Messaging, which is free).

Requirements: PHP **8.1+** with `pdo_mysql`, `curl` and `openssl` (standard on cPanel), MySQL/MariaDB,
cron jobs and SSL (AutoSSL / Let's Encrypt). Plan on about 30 minutes.

---

## 1. Create the subdomain
cPanel → **Domains** → Create a new domain: `api.yourdomain.com`
- **Document root:** `signallab/public` (uncheck "share document root")
- cPanel → **SSL/TLS Status** → run AutoSSL so `https://api.yourdomain.com` works.

## 2. Upload the files
cPanel → **File Manager** → your home folder (`/home/USER/`), not public_html:
1. Create folder `signallab`
2. Upload the `server/` contents so you have:
```
/home/USER/signallab/app/      ← code, config, cron (NOT web-accessible)
/home/USER/signallab/public/   ← index.php + .htaccess (the subdomain root)
```
3. Make `app/storage` writable (permissions 755).

## 3. Database
cPanel → **MySQL® Databases**
1. Create database `USER_signallab`
2. Create user `USER_signallab` with a strong password
3. Add the user to the database with **ALL PRIVILEGES**

(Tables are created in step 6.)

## 4. Email mailbox
cPanel → **Email Accounts** → create `signals@yourdomain.com`.
Then **Connect Devices** shows the SMTP host and port (usually `mail.yourdomain.com`, port **465**, SSL).
For better inbox delivery: cPanel → **Email Deliverability** → make sure **SPF** and **DKIM** are valid.

## 5. Configuration
Copy `app/config.sample.php` → `app/config.php` and fill in:
| Setting | Value |
|---|---|
| `base_url` | `https://api.yourdomain.com` |
| `db.*` | database, user and password from step 3 |
| `jwt_secret` | a long random string (cPanel → Terminal: `php -r "echo bin2hex(random_bytes(32));"`) |
| `mail.*` | mailbox from step 4 |
| `google.client_ids` | your Google OAuth client IDs (step 8) |
| `developer.*` | already set to your WhatsApp and Buy Me a Coffee links |

## 6. Install check
cPanel → **Terminal** (or SSH):
```bash
cd ~/signallab
php app/cron/install.php --test-email you@gmail.com
```
It creates the tables and checks the database, secret, storage, email and push setup.
Open `https://api.yourdomain.com/health` → should show `"status":"ok"`.

## 7. Cron jobs
cPanel → **Cron Jobs** (replace `USER`; if `php` isn't found use `/usr/local/bin/php`):
| Schedule | Command | Purpose |
|---|---|---|
| `5,35 * * * *` | `php /home/USER/signallab/app/cron/scan.php >/dev/null 2>&1` | scan market, record & close signals, send alerts |
| `*/5 * * * *` | `php /home/USER/signallab/app/cron/send_mail.php >/dev/null 2>&1` | send queued emails |
| `30 21 * * 1-5` | `php /home/USER/signallab/app/cron/reports.php daily >/dev/null 2>&1` | daily report (after US close) |
| `0 9 * * 6` | `php /home/USER/signallab/app/cron/reports.php weekly >/dev/null 2>&1` | weekly report |
| `0 9 1 * *` | `php /home/USER/signallab/app/cron/reports.php monthly >/dev/null 2>&1` | monthly report |

Cron times use the server's clock. Check the timezone at the top of cPanel's Cron page.
If your host has no CLI cron, set `cron_key` in config and call
`https://api.yourdomain.com/cron/scan?key=YOUR_KEY` from a free service like cron-job.org.

## 8. Firebase (push) and Google Sign-In
1. https://console.firebase.google.com → **Add project** → add an **Android app** with package
   `com.swiftmynd.signal_lab` (and an iOS app if you publish there).
2. In the Flutter project: `dart pub global activate flutterfire_cli` → `flutterfire configure`
   (adds `google-services.json` and the Gradle plugin).
3. Firebase → Project settings → **Service accounts** → *Generate new private key* → upload the JSON
   to `app/firebase-service-account.json` (next to config.php, never in public/).
4. Google Sign-In: Firebase → Authentication → Sign-in method → enable **Google** (this creates the
   OAuth clients). Add your app's **SHA-1** (Play Console → App integrity, and your debug key).
   Copy the **Web client ID** into `config.php → google.client_ids` and build the app with
   `--dart-define=GOOGLE_SERVER_CLIENT_ID=<that id>`.

## 9. Point the app at your API
```bash
flutter build appbundle --release \
  --dart-define=API_BASE_URL=https://api.yourdomain.com \
  --dart-define=GOOGLE_SERVER_CLIENT_ID=XXXX.apps.googleusercontent.com
```

## Public pages your server provides
- `https://api.yourdomain.com/record`: public live track record (share it to build trust)
- `https://api.yourdomain.com/privacy`: privacy policy (use as the Play Store privacy URL)
- `https://api.yourdomain.com/delete-account`: account deletion page (required by Google Play)

## Maintenance
- `https://api.yourdomain.com/health` shows the last scan time.
- Errors go to cPanel → **Errors** / `error_log`. The `scan_log` table records every scan.
- Back up the database with cPanel → **Backup**. The signals table *is* your track record.

## Testing locally (optional, for developers)
```bash
# needs PHP 8.1+, MariaDB/MySQL, Python 3
python3 app/tests/tools/smtp_catcher.py &      # fake mail server on :2525
php app/tests/run.php                           # 78 integration tests
```
